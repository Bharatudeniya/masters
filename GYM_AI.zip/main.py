import os
import cv2
import math
import pickle
import datetime
import warnings
import numpy as np
import pandas as pd
import tkinter as tk
import mediapipe as mp
from PIL import Image, ImageTk

# root_path = /home/hb/PycharmProjects/Gym AI/venv/lib/python3.8/site-packages
current_directory = os.getcwd()

tipIds = [4, 8, 12, 16, 20]
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
hands = mp_hands.Hands(min_detection_confidence=0.8, min_tracking_confidence=0.5)


def hand_detection(image, canvas, cap):
    imgRGB = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    results = hands.process(imgRGB)
    hand_landmarks = results.multi_hand_landmarks

    if hand_landmarks:
        finger_count = countFingers(image, hand_landmarks)
        if finger_count == 4:
            show_camera_feed(canvas, cap)


def track_planks(canvas, cap):
    root.title("PLANK")
    canvas.update()
    canvas = tk.Canvas(canvas, width=640, height=480)
    canvas.pack()
    warnings.filterwarnings('ignore')

    mp_drawing = mp.solutions.drawing_utils
    mp_pose = mp.solutions.pose

    IMPORTANT_LMS = [
        "NOSE",
        "LEFT_SHOULDER",
        "RIGHT_SHOULDER",
        "LEFT_ELBOW",
        "RIGHT_ELBOW",
        "LEFT_WRIST",
        "RIGHT_WRIST",
        "LEFT_HIP",
        "RIGHT_HIP",
        "LEFT_KNEE",
        "RIGHT_KNEE",
        "LEFT_ANKLE",
        "RIGHT_ANKLE",
        "LEFT_HEEL",
        "RIGHT_HEEL",
        "LEFT_FOOT_INDEX",
        "RIGHT_FOOT_INDEX",
    ]

    HEADERS = ["label"]

    for lm in IMPORTANT_LMS:
        HEADERS += [f"{lm.lower()}_x", f"{lm.lower()}_y", f"{lm.lower()}_z", f"{lm.lower()}_v"]

    def extract_important_keypoints(results) -> list:
        landmarks = results.pose_landmarks.landmark

        data = []
        for lm in IMPORTANT_LMS:
            keypoint = landmarks[mp_pose.PoseLandmark[lm].value]
            data.append([keypoint.x, keypoint.y, keypoint.z, keypoint.visibility])

        return np.array(data).flatten().tolist()

    def rescale_frame(frame, percent=50):
        width = int(frame.shape[1] * percent / 100)
        height = int(frame.shape[0] * percent / 100)
        dim = (width, height)
        return cv2.resize(frame, dim, interpolation=cv2.INTER_AREA)

    lr_model_path = os.path.join(current_directory, "Plank/model/LR_model.pkl")
    with open(lr_model_path, "rb") as f:
        sklearn_model = pickle.load(f)

    input_scaler_path = os.path.join(current_directory, "Plank/model/input_scaler.pkl")
    with open(input_scaler_path, "rb") as f2:
        input_scaler = pickle.load(f2)

    def get_class(prediction: float) -> str:
        return {
            0: "C",
            1: "H",
            2: "L",
        }.get(prediction)

    # cap = cv2.VideoCapture(0)
    current_stage = ""
    prediction_probability_threshold = 0.6

    with mp_pose.Pose(min_detection_confidence=0.5, min_tracking_confidence=0.5) as pose:
        while cap.isOpened():
            ret, image = cap.read()

            if not ret:
                break
            hand_detection(image, canvas, cap)

            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            image.flags.writeable = False

            results = pose.process(image)

            if not results.pose_landmarks:
                print("No human found")
                continue

            image.flags.writeable = True
            image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

            mp_drawing.draw_landmarks(image, results.pose_landmarks, mp_pose.POSE_CONNECTIONS,
                                      mp_drawing.DrawingSpec(color=(244, 117, 66), thickness=2, circle_radius=2),
                                      mp_drawing.DrawingSpec(color=(245, 66, 230), thickness=2, circle_radius=1))

            try:
                row = extract_important_keypoints(results)
                X = pd.DataFrame([row], columns=HEADERS[1:])
                X = pd.DataFrame(input_scaler.transform(X))

                predicted_class = sklearn_model.predict(X)[0]
                predicted_class = get_class(predicted_class)
                prediction_probability = sklearn_model.predict_proba(X)[0]

                if predicted_class == "C" and prediction_probability[
                    prediction_probability.argmax()] >= prediction_probability_threshold:
                    current_stage = "Correct"
                elif predicted_class == "L" and prediction_probability[
                    prediction_probability.argmax()] >= prediction_probability_threshold:
                    current_stage = "Low back"
                elif predicted_class == "H" and prediction_probability[
                    prediction_probability.argmax()] >= prediction_probability_threshold:
                    current_stage = "High back"
                else:
                    current_stage = "unk"

                cv2.rectangle(image, (0, 0), (250, 60), (245, 117, 16), -1)

                cv2.putText(image, "CLASS", (95, 12), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(image, current_stage, (90, 40), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2,
                            cv2.LINE_AA)

                cv2.putText(image, "PROB", (15, 12), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(image, str(round(prediction_probability[np.argmax(prediction_probability)], 2)), (10, 40),
                            cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2, cv2.LINE_AA)

            except Exception as e:
                print(f"Error: {e}")

            # cv2.imshow("CV2", image)
            photo = ImageTk.PhotoImage(image=Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB)))
            canvas.create_image(0, 0, image=photo, anchor=tk.NW)
            canvas.photo = photo
            canvas.update()

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        cap.release()
        cv2.destroyAllWindows()

        for i in range(1, 5):
            cv2.waitKey(1)

    prediction_probability_threshold = 0.6

    plank_dp__model_path = os.path.join(current_directory, "Plank/model/plank_dp.pkl")
    with open(plank_dp__model_path, "rb") as f:
        deep_learning_model = pickle.load(f)

    with mp_pose.Pose(min_detection_confidence=0.5, min_tracking_confidence=0.5) as pose:
        while cap.isOpened():
            ret, image = cap.read()

            if not ret:
                break

            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            image.flags.writeable = False

            results = pose.process(image)

            if not results.pose_landmarks:
                print("No human found")
                continue

            image.flags.writeable = True
            image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

            mp_drawing.draw_landmarks(image, results.pose_landmarks, mp_pose.POSE_CONNECTIONS,
                                      mp_drawing.DrawingSpec(color=(244, 117, 66), thickness=2, circle_radius=2),
                                      mp_drawing.DrawingSpec(color=(245, 66, 230), thickness=2, circle_radius=1))

            try:
                row = extract_important_keypoints(results)
                X = pd.DataFrame([row, ], columns=HEADERS[1:])
                X = pd.DataFrame(input_scaler.transform(X))

                prediction = deep_learning_model.predict(X)
                predicted_class = np.argmax(prediction, axis=1)[0]

                prediction_probability = max(prediction.tolist()[0])

                if predicted_class == 0 and prediction_probability >= prediction_probability_threshold:
                    current_stage = "Correct"
                elif predicted_class == 2 and prediction_probability >= prediction_probability_threshold:
                    current_stage = "Low back"
                elif predicted_class == 1 and prediction_probability >= prediction_probability_threshold:
                    current_stage = "High back"
                else:
                    current_stage = "Unknown"

                cv2.rectangle(image, (0, 0), (550, 60), (245, 117, 16), -1)

                cv2.putText(image, "DETECTION", (95, 12), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(image, current_stage, (90, 40), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2,
                            cv2.LINE_AA)

                cv2.putText(image, "CLASS", (350, 12), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(image, str(predicted_class), (345, 40), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2,
                            cv2.LINE_AA)

                cv2.putText(image, "PROB", (15, 12), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(image, str(round(prediction_probability, 2)), (10, 40), cv2.FONT_HERSHEY_COMPLEX, 1,
                            (255, 255, 255), 2, cv2.LINE_AA)

            except Exception as e:
                print(f"Error: {e}")

            photo = ImageTk.PhotoImage(image=Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB)))
            canvas.create_image(0, 0, image=photo, anchor=tk.NW)
            canvas.photo = photo
            canvas.update()

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    cap.release()
    cv2.destroyAllWindows()

    for i in range(1, 5):
        cv2.waitKey(1)


def track_sitUps(canvas, cap):
    root.title("SIT-UP")
    canvas.update()
    canvas = tk.Canvas(canvas, width=640, height=480)
    canvas.pack()

    mp_drawing = mp.solutions.drawing_utils
    mp_pose = mp.solutions.pose
    IMPORTANT_LMS = [
        "NOSE",
        "LEFT_SHOULDER",
        "RIGHT_SHOULDER",
        "LEFT_HIP",
        "RIGHT_HIP",
        "LEFT_KNEE",
        "RIGHT_KNEE",
        "LEFT_ANKLE",
        "RIGHT_ANKLE"
    ]

    headers = ["label"]

    for lm in IMPORTANT_LMS:
        headers += [f"{lm.lower()}_x", f"{lm.lower()}_y", f"{lm.lower()}_z", f"{lm.lower()}_v"]

    def extract_important_keypoints(results) -> list:
        landmarks = results.pose_landmarks.landmark

        data = []
        for lm in IMPORTANT_LMS:
            keypoint = landmarks[mp_pose.PoseLandmark[lm].value]
            data.append([keypoint.x, keypoint.y, keypoint.z, keypoint.visibility])

        return np.array(data).flatten().tolist()

    def rescale_frame(frame, percent=50):
        width = int(frame.shape[1] * percent / 30)  # USE /100
        height = int(frame.shape[0] * percent / 30)  # USE /100
        dim = (width, height)
        return cv2.resize(frame, dim, interpolation=cv2.INTER_AREA)

    def calculate_distance(pointX, pointY) -> float:
        x1, y1 = pointX
        x2, y2 = pointY

        return math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)

    def analyze_foot_knee_placement(results, stage: str, foot_shoulder_ratio_thresholds: list,
                                    knee_foot_ratio_thresholds: dict, visibility_threshold: int) -> dict:
        analyzed_results = {
            "foot_placement": -1,
            "knee_placement": -1,
        }

        landmarks = results.pose_landmarks.landmark

        left_foot_index_vis = landmarks[mp_pose.PoseLandmark.LEFT_FOOT_INDEX.value].visibility
        right_foot_index_vis = landmarks[mp_pose.PoseLandmark.RIGHT_FOOT_INDEX.value].visibility

        left_knee_vis = landmarks[mp_pose.PoseLandmark.LEFT_KNEE.value].visibility
        right_knee_vis = landmarks[mp_pose.PoseLandmark.RIGHT_KNEE.value].visibility

        if (
                left_foot_index_vis < visibility_threshold or right_foot_index_vis < visibility_threshold or left_knee_vis < visibility_threshold or right_knee_vis < visibility_threshold):
            return analyzed_results

        left_shoulder = [landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value].x,
                         landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value].y]
        right_shoulder = [landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value].x,
                          landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value].y]
        shoulder_width = calculate_distance(left_shoulder, right_shoulder)

        left_foot_index = [landmarks[mp_pose.PoseLandmark.LEFT_FOOT_INDEX.value].x,
                           landmarks[mp_pose.PoseLandmark.LEFT_FOOT_INDEX.value].y]
        right_foot_index = [landmarks[mp_pose.PoseLandmark.RIGHT_FOOT_INDEX.value].x,
                            landmarks[mp_pose.PoseLandmark.RIGHT_FOOT_INDEX.value].y]
        foot_width = calculate_distance(left_foot_index, right_foot_index)

        foot_shoulder_ratio = round(foot_width / shoulder_width, 1)

        min_ratio_foot_shoulder, max_ratio_foot_shoulder = foot_shoulder_ratio_thresholds
        if min_ratio_foot_shoulder <= foot_shoulder_ratio <= max_ratio_foot_shoulder:
            analyzed_results["foot_placement"] = 0
        elif foot_shoulder_ratio < min_ratio_foot_shoulder:
            analyzed_results["foot_placement"] = 1
        elif foot_shoulder_ratio > max_ratio_foot_shoulder:
            analyzed_results["foot_placement"] = 2

        left_knee_vis = landmarks[mp_pose.PoseLandmark.LEFT_KNEE.value].visibility
        right_knee_vis = landmarks[mp_pose.PoseLandmark.RIGHT_KNEE.value].visibility

        if left_knee_vis < visibility_threshold or right_knee_vis < visibility_threshold:
            print("Cannot see foot")
            return analyzed_results

        left_knee = [landmarks[mp_pose.PoseLandmark.LEFT_KNEE.value].x,
                     landmarks[mp_pose.PoseLandmark.LEFT_KNEE.value].y]
        right_knee = [landmarks[mp_pose.PoseLandmark.RIGHT_KNEE.value].x,
                      landmarks[mp_pose.PoseLandmark.RIGHT_KNEE.value].y]
        knee_width = calculate_distance(left_knee, right_knee)

        knee_foot_ratio = round(knee_width / foot_width, 1)

        up_min_ratio_knee_foot, up_max_ratio_knee_foot = knee_foot_ratio_thresholds.get("up")
        middle_min_ratio_knee_foot, middle_max_ratio_knee_foot = knee_foot_ratio_thresholds.get("middle")
        down_min_ratio_knee_foot, down_max_ratio_knee_foot = knee_foot_ratio_thresholds.get("down")

        if stage == "up":
            if up_min_ratio_knee_foot <= knee_foot_ratio <= up_max_ratio_knee_foot:
                analyzed_results["knee_placement"] = 0
            elif knee_foot_ratio < up_min_ratio_knee_foot:
                analyzed_results["knee_placement"] = 1
            elif knee_foot_ratio > up_max_ratio_knee_foot:
                analyzed_results["knee_placement"] = 2
        elif stage == "middle":
            if middle_min_ratio_knee_foot <= knee_foot_ratio <= middle_max_ratio_knee_foot:
                analyzed_results["knee_placement"] = 0
            elif knee_foot_ratio < middle_min_ratio_knee_foot:
                analyzed_results["knee_placement"] = 1
            elif knee_foot_ratio > middle_max_ratio_knee_foot:
                analyzed_results["knee_placement"] = 2
        elif stage == "down":
            if down_min_ratio_knee_foot <= knee_foot_ratio <= down_max_ratio_knee_foot:
                analyzed_results["knee_placement"] = 0
            elif knee_foot_ratio < down_min_ratio_knee_foot:
                analyzed_results["knee_placement"] = 1
            elif knee_foot_ratio > down_max_ratio_knee_foot:
                analyzed_results["knee_placement"] = 2

        return analyzed_results

    sitUps_lr_model_path = os.path.join(current_directory, "SitUps/model/LR_model.pkl")
    with open(sitUps_lr_model_path, "rb") as f:
        count_model = pickle.load(f)
    # cap = cv2.VideoCapture(0)

    counter = 0
    current_stage = ""
    PREDICTION_PROB_THRESHOLD = 0.7

    VISIBILITY_THRESHOLD = 0.6
    FOOT_SHOULDER_RATIO_THRESHOLDS = [1.2, 2.8]
    KNEE_FOOT_RATIO_THRESHOLDS = {
        "up": [0.5, 1.0],
        "middle": [0.7, 1.0],
        "down": [0.7, 1.1],
    }

    with mp_pose.Pose(min_detection_confidence=0.5, min_tracking_confidence=0.5) as pose:
        while cap.isOpened():
            ret, image = cap.read()

            if not ret:
                break

            hand_detection(image, canvas, cap)

            # image = rescale_frame(image, 50)
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            image.flags.writeable = False

            results = pose.process(image)
            if not results.pose_landmarks:
                continue

            image.flags.writeable = True
            image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

            mp_drawing.draw_landmarks(image, results.pose_landmarks, mp_pose.POSE_CONNECTIONS,
                                      mp_drawing.DrawingSpec(color=(244, 117, 66), thickness=2, circle_radius=2),
                                      mp_drawing.DrawingSpec(color=(245, 66, 230), thickness=2, circle_radius=1))

            try:
                row = extract_important_keypoints(results)
                X = pd.DataFrame([row])

                predicted_class = count_model.predict(X)[0]
                predicted_class = "down" if predicted_class == 0 else "up"
                prediction_probabilities = count_model.predict_proba(X)[0]
                prediction_probability = round(prediction_probabilities[prediction_probabilities.argmax()], 2)

                if predicted_class == "down" and prediction_probability >= PREDICTION_PROB_THRESHOLD:
                    current_stage = "down"
                elif current_stage == "down" and predicted_class == "up" and prediction_probability >= PREDICTION_PROB_THRESHOLD:
                    current_stage = "up"
                    counter += 1

                analyzed_results = analyze_foot_knee_placement(results=results, stage=current_stage,
                                                               foot_shoulder_ratio_thresholds=FOOT_SHOULDER_RATIO_THRESHOLDS,
                                                               knee_foot_ratio_thresholds=KNEE_FOOT_RATIO_THRESHOLDS,
                                                               visibility_threshold=VISIBILITY_THRESHOLD)

                foot_placement_evaluation = analyzed_results["foot_placement"]
                knee_placement_evaluation = analyzed_results["knee_placement"]

                if foot_placement_evaluation == -1:
                    foot_placement = "UNK"
                elif foot_placement_evaluation == 0:
                    foot_placement = "Correct"
                elif foot_placement_evaluation == 1:
                    foot_placement = "Too tight"
                elif foot_placement_evaluation == 2:
                    foot_placement = "Too wide"

                if knee_placement_evaluation == -1:
                    knee_placement = "UNK"
                elif knee_placement_evaluation == 0:
                    knee_placement = "Correct"
                elif knee_placement_evaluation == 1:
                    knee_placement = "Too tight"
                elif knee_placement_evaluation == 2:
                    knee_placement = "Too wide"

                cv2.rectangle(image, (0, 0), (500, 60), (245, 117, 16), -1)
                cv2.putText(image, "COUNT", (10, 12), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(image, f'{str(counter)}, {predicted_class}, {str(prediction_probability)}', (5, 40),
                            cv2.FONT_HERSHEY_COMPLEX, .7, (255, 255, 255), 2, cv2.LINE_AA)

                cv2.putText(image, "FOOT", (200, 12), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(image, foot_placement, (195, 40), cv2.FONT_HERSHEY_COMPLEX, .7, (255, 255, 255), 2,
                            cv2.LINE_AA)

                cv2.putText(image, "KNEE", (330, 12), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(image, knee_placement, (325, 40), cv2.FONT_HERSHEY_COMPLEX, .7, (255, 255, 255), 2,
                            cv2.LINE_AA)

            except Exception as e:
                print(f"Error: {e}")

            photo = ImageTk.PhotoImage(image=Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB)))
            canvas.create_image(0, 0, image=photo, anchor=tk.NW)
            canvas.photo = photo
            canvas.update()

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        cap.release()
        cv2.destroyAllWindows()

        for i in range(1, 5):
            cv2.waitKey(1)


def track_biceps(canvas, cap):
    root.title("BICEPS")
    # cap = cv2.VideoCapture('/home/hb/Desktop/downloads/Bicep Workout _ 4 Bicep Exercises For Bigger Arms 🔥.mp4')
    canvas.update()
    canvas = tk.Canvas(canvas, width=640, height=480)
    canvas.pack()
    warnings.filterwarnings('ignore')
    mp_drawing = mp.solutions.drawing_utils
    mp_pose = mp.solutions.pose
    # mp_hands = mp.solutions.hands
    #
    # hands = mp_hands.Hands(min_detection_confidence=0.5, min_tracking_confidence=0.5)
    #
    # tipIds = [4, 8, 12, 16, 20]

    IMPORTANT_LMS = [
        "NOSE",
        "LEFT_SHOULDER",
        "RIGHT_SHOULDER",
        "RIGHT_ELBOW",
        "LEFT_ELBOW",
        "RIGHT_WRIST",
        "LEFT_WRIST",
        "LEFT_HIP",
        "RIGHT_HIP",
    ]

    HEADERS = ["label"]

    for lm in IMPORTANT_LMS:
        HEADERS += [f"{lm.lower()}_x", f"{lm.lower()}_y", f"{lm.lower()}_z", f"{lm.lower()}_v"]

    def rescale_frame(frame, percent=50):
        width = int(frame.shape[1] * percent / 30)
        height = int(frame.shape[0] * percent / 30)
        dim = (width, height)
        return cv2.resize(frame, dim, interpolation=cv2.INTER_AREA)

    def save_frame_as_image(frame, message: str = None):
        now = datetime.datetime.now()

        if message:
            cv2.putText(frame, message, (50, 150), cv2.FONT_HERSHEY_COMPLEX, 0.4, (0, 0, 0), 1, cv2.LINE_AA)

        print("Saving ...")
        cv2.imwrite(f"../data/logs/bicep_{now}.jpg", frame)

    def calculate_angle(point1: list, point2: list, point3: list) -> float:
        point1 = np.array(point1)
        point2 = np.array(point2)
        point3 = np.array(point3)

        angleInRad = np.arctan2(point3[1] - point2[1], point3[0] - point2[0]) - np.arctan2(point1[1] - point2[1],
                                                                                           point1[0] - point2[0])
        angleInDeg = np.abs(angleInRad * 180.0 / np.pi)

        angleInDeg = angleInDeg if angleInDeg <= 180 else 360 - angleInDeg
        return angleInDeg

    def extract_important_keypoints(results, important_landmarks: list) -> list:
        landmarks = results.pose_landmarks.landmark

        data = []
        for lm in important_landmarks:
            keypoint = landmarks[mp_pose.PoseLandmark[lm].value]
            data.append([keypoint.x, keypoint.y, keypoint.z, keypoint.visibility])

        return np.array(data).flatten().tolist()

    class BicepPoseAnalysis:
        def __init__(self, side: str, stage_down_threshold: float, stage_up_threshold: float,
                     peak_contraction_threshold: float, loose_upper_arm_angle_threshold: float,
                     visibility_threshold: float):
            # Initialize thresholds
            self.stage_down_threshold = stage_down_threshold
            self.stage_up_threshold = stage_up_threshold
            self.peak_contraction_threshold = peak_contraction_threshold
            self.loose_upper_arm_angle_threshold = loose_upper_arm_angle_threshold
            self.visibility_threshold = visibility_threshold

            self.side = side
            self.counter = 0
            self.stage = "down"
            self.is_visible = True
            self.detected_errors = {
                "LOOSE_UPPER_ARM": 0,
                "PEAK_CONTRACTION": 0,
            }

            self.loose_upper_arm = False
            self.peak_contraction_angle = 1000
            self.peak_contraction_frame = None

        def get_joints(self, landmarks) -> bool:
            side = self.side.upper()

            joints_visibility = [landmarks[mp_pose.PoseLandmark[f"{side}_SHOULDER"].value].visibility,
                                 landmarks[mp_pose.PoseLandmark[f"{side}_ELBOW"].value].visibility,
                                 landmarks[mp_pose.PoseLandmark[f"{side}_WRIST"].value].visibility]

            is_visible = all([vis > self.visibility_threshold for vis in joints_visibility])
            self.is_visible = is_visible

            if not is_visible:
                return self.is_visible

            # Get joints' coordinates
            self.shoulder = [landmarks[mp_pose.PoseLandmark[f"{side}_SHOULDER"].value].x,
                             landmarks[mp_pose.PoseLandmark[f"{side}_SHOULDER"].value].y]
            self.elbow = [landmarks[mp_pose.PoseLandmark[f"{side}_ELBOW"].value].x,
                          landmarks[mp_pose.PoseLandmark[f"{side}_ELBOW"].value].y]
            self.wrist = [landmarks[mp_pose.PoseLandmark[f"{side}_WRIST"].value].x,
                          landmarks[mp_pose.PoseLandmark[f"{side}_WRIST"].value].y]

            return self.is_visible

        def analyze_pose(self, landmarks, frame):

            self.get_joints(landmarks)

            if not self.is_visible:
                return (None, None)

            bicep_curl_angle = int(calculate_angle(self.shoulder, self.elbow, self.wrist))
            if bicep_curl_angle > self.stage_down_threshold:
                self.stage = "down"
            elif bicep_curl_angle < self.stage_up_threshold and self.stage == "down":
                self.stage = "up"
                self.counter += 1

            shoulder_projection = [self.shoulder[0], 1]
            ground_upper_arm_angle = int(calculate_angle(self.elbow, self.shoulder, shoulder_projection))

            if ground_upper_arm_angle > self.loose_upper_arm_angle_threshold:
                if not self.loose_upper_arm:
                    self.loose_upper_arm = True
                    self.detected_errors["LOOSE_UPPER_ARM"] += 1
            else:
                self.loose_upper_arm = False

            if self.stage == "up" and bicep_curl_angle < self.peak_contraction_angle:
                self.peak_contraction_angle = bicep_curl_angle
                self.peak_contraction_frame = frame

            elif self.stage == "down":
                if self.peak_contraction_angle != 1000 and self.peak_contraction_angle >= self.peak_contraction_threshold:
                    self.detected_errors["PEAK_CONTRACTION"] += 1

                self.peak_contraction_angle = 1000
                self.peak_contraction_frame = None

            return (bicep_curl_angle, ground_upper_arm_angle)

    biceps_input_scaler_model_path = os.path.join(current_directory, "Biceps/model/input_scaler.pkl")
    with open(biceps_input_scaler_model_path, "rb") as f:
        input_scaler = pickle.load(f)

    biceps_knn_model_path = os.path.join(current_directory, "Biceps/model/KNN_model.pkl")
    with open(biceps_knn_model_path, "rb") as f:
        sklearn_model = pickle.load(f)
    # cap = cv2.VideoCapture(0)

    VISIBILITY_THRESHOLD = 0.65
    STAGE_UP_THRESHOLD = 90
    STAGE_DOWN_THRESHOLD = 120
    PEAK_CONTRACTION_THRESHOLD = 60
    LOOSE_UPPER_ARM = False
    LOOSE_UPPER_ARM_ANGLE_THRESHOLD = 40
    POSTURE_ERROR_THRESHOLD = 0.7
    posture = "C"
    left_arm_analysis = BicepPoseAnalysis(side="left", stage_down_threshold=STAGE_DOWN_THRESHOLD,
                                          stage_up_threshold=STAGE_UP_THRESHOLD,
                                          peak_contraction_threshold=PEAK_CONTRACTION_THRESHOLD,
                                          loose_upper_arm_angle_threshold=LOOSE_UPPER_ARM_ANGLE_THRESHOLD,
                                          visibility_threshold=VISIBILITY_THRESHOLD)

    right_arm_analysis = BicepPoseAnalysis(side="right", stage_down_threshold=STAGE_DOWN_THRESHOLD,
                                           stage_up_threshold=STAGE_UP_THRESHOLD,
                                           peak_contraction_threshold=PEAK_CONTRACTION_THRESHOLD,
                                           loose_upper_arm_angle_threshold=LOOSE_UPPER_ARM_ANGLE_THRESHOLD,
                                           visibility_threshold=VISIBILITY_THRESHOLD)

    with mp_pose.Pose(min_detection_confidence=0.8, min_tracking_confidence=0.8) as pose:
        while cap.isOpened():
            ret, img = cap.read()

            if not ret:
                break

            # detector = handDetector()
            # img = detector.findHands(image)
            hand_detection(img, canvas, cap)

            video_dimensions = [img.shape[1], img.shape[0]]
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            img.flags.writeable = False
            results = pose.process(img)

            if not results.pose_landmarks:
                print("No human found")
                continue

            img.flags.writeable = True
            img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)

            mp_drawing.draw_landmarks(img, results.pose_landmarks, mp_pose.POSE_CONNECTIONS,
                                      mp_drawing.DrawingSpec(color=(244, 117, 66), thickness=2, circle_radius=2),
                                      mp_drawing.DrawingSpec(color=(245, 66, 230), thickness=2, circle_radius=1))

            try:
                landmarks = results.pose_landmarks.landmark

                (left_bicep_curl_angle, left_ground_upper_arm_angle) = left_arm_analysis.analyze_pose(
                    landmarks=landmarks,
                    frame=img)
                (right_bicep_curl_angle, right_ground_upper_arm_angle) = right_arm_analysis.analyze_pose(
                    landmarks=landmarks, frame=img)

                row = extract_important_keypoints(results, IMPORTANT_LMS)
                X = pd.DataFrame([row], columns=HEADERS[1:])
                X = pd.DataFrame(input_scaler.transform(X))
                predicted_class = sklearn_model.predict(X)[0]
                prediction_probabilities = sklearn_model.predict_proba(X)[0]
                class_prediction_probability = round(prediction_probabilities[np.argmax(prediction_probabilities)], 2)

                if class_prediction_probability >= POSTURE_ERROR_THRESHOLD:
                    posture = predicted_class

                cv2.rectangle(img, (0, 0), (500, 40), (245, 117, 16), -1)
                cv2.putText(img, "RIGHT", (15, 12), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(img, str(right_arm_analysis.counter) if right_arm_analysis.is_visible else "UNK",
                            (10, 30),
                            cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255), 2, cv2.LINE_AA)

                cv2.putText(img, "LEFT", (95, 12), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(img, str(left_arm_analysis.counter) if left_arm_analysis.is_visible else "UNK", (100, 30),
                            cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255), 2, cv2.LINE_AA)

                cv2.putText(img, "R_PC", (165, 12), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(img, str(right_arm_analysis.detected_errors["PEAK_CONTRACTION"]), (160, 30),
                            cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255), 2, cv2.LINE_AA)
                cv2.putText(img, "R_LUA", (225, 12), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(img, str(right_arm_analysis.detected_errors["LOOSE_UPPER_ARM"]), (220, 30),
                            cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255), 2, cv2.LINE_AA)

                cv2.putText(img, "L_PC", (300, 12), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(img, str(left_arm_analysis.detected_errors["PEAK_CONTRACTION"]), (295, 30),
                            cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255), 2, cv2.LINE_AA)
                cv2.putText(img, "L_LUA", (380, 12), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(img, str(left_arm_analysis.detected_errors["LOOSE_UPPER_ARM"]), (375, 30),
                            cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255), 2, cv2.LINE_AA)

                cv2.putText(img, "LB", (460, 12), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(img, str(f"{posture}, {predicted_class}, {class_prediction_probability}"), (440, 30),
                            cv2.FONT_HERSHEY_COMPLEX, 0.3, (255, 255, 255), 1, cv2.LINE_AA)

                if left_arm_analysis.is_visible:
                    cv2.putText(img, str(left_bicep_curl_angle),
                                tuple(np.multiply(left_arm_analysis.elbow, video_dimensions).astype(int)),
                                cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)
                    cv2.putText(img, str(left_ground_upper_arm_angle),
                                tuple(np.multiply(left_arm_analysis.shoulder, video_dimensions).astype(int)),
                                cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)

                if right_arm_analysis.is_visible:
                    cv2.putText(img, str(right_bicep_curl_angle),
                                tuple(np.multiply(right_arm_analysis.elbow, video_dimensions).astype(int)),
                                cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 0), 1, cv2.LINE_AA)
                    cv2.putText(img, str(right_ground_upper_arm_angle),
                                tuple(np.multiply(right_arm_analysis.shoulder, video_dimensions).astype(int)),
                                cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 0), 1, cv2.LINE_AA)

            except Exception as e:
                print(f"Error: {e}")
            # cv2.imshow("CV2", image)
            photo = ImageTk.PhotoImage(image=Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB)))
            canvas.create_image(0, 0, image=photo, anchor=tk.NW)
            canvas.photo = photo
            canvas.update()

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        cap.release()
        cv2.destroyAllWindows()

        for i in range(1, 5):
            cv2.waitKey(1)

    biceps_dp_model_path = os.path.join(current_directory, "Biceps/model/bicep_dp.pkl")
    with open(biceps_dp_model_path, "rb") as f:
        DL_model = pickle.load(f)

    VISIBILITY_THRESHOLD = 0.65

    STAGE_UP_THRESHOLD = 90
    STAGE_DOWN_THRESHOLD = 120

    PEAK_CONTRACTION_THRESHOLD = 60
    LOOSE_UPPER_ARM = False
    LOOSE_UPPER_ARM_ANGLE_THRESHOLD = 40
    POSTURE_ERROR_THRESHOLD = 0.95
    posture = 0
    left_arm_analysis = BicepPoseAnalysis(side="left", stage_down_threshold=STAGE_DOWN_THRESHOLD,
                                          stage_up_threshold=STAGE_UP_THRESHOLD,
                                          peak_contraction_threshold=PEAK_CONTRACTION_THRESHOLD,
                                          loose_upper_arm_angle_threshold=LOOSE_UPPER_ARM_ANGLE_THRESHOLD,
                                          visibility_threshold=VISIBILITY_THRESHOLD)

    right_arm_analysis = BicepPoseAnalysis(side="right", stage_down_threshold=STAGE_DOWN_THRESHOLD,
                                           stage_up_threshold=STAGE_UP_THRESHOLD,
                                           peak_contraction_threshold=PEAK_CONTRACTION_THRESHOLD,
                                           loose_upper_arm_angle_threshold=LOOSE_UPPER_ARM_ANGLE_THRESHOLD,
                                           visibility_threshold=VISIBILITY_THRESHOLD)

    with mp_pose.Pose(min_detection_confidence=0.5, min_tracking_confidence=0.5) as pose:
        while cap.isOpened():
            ret, image = cap.read()

            if not ret:
                break

            image = rescale_frame(image, 40)
            video_dimensions = [image.shape[1], image.shape[0]]
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            image.flags.writeable = False
            results = pose.process(image)
            print(results)

            if not results.pose_landmarks:
                print("No human found")
                continue

            image.flags.writeable = True
            image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
            mp_drawing.draw_landmarks(image, results.pose_landmarks, mp_pose.POSE_CONNECTIONS,
                                      mp_drawing.DrawingSpec(color=(244, 117, 66), thickness=2, circle_radius=2),
                                      mp_drawing.DrawingSpec(color=(245, 66, 230), thickness=2, circle_radius=1))

            try:
                landmarks = results.pose_landmarks.landmark

                (left_bicep_curl_angle, left_ground_upper_arm_angle) = left_arm_analysis.analyze_pose(
                    landmarks=landmarks,
                    frame=image)
                (right_bicep_curl_angle, right_ground_upper_arm_angle) = right_arm_analysis.analyze_pose(
                    landmarks=landmarks, frame=image)

                row = extract_important_keypoints(results, IMPORTANT_LMS)
                X = pd.DataFrame([row, ], columns=HEADERS[1:])
                X = pd.DataFrame(input_scaler.transform(X))

                prediction = DL_model.predict(X)
                predicted_class = np.argmax(prediction, axis=1)[0]
                prediction_probability = round(max(prediction.tolist()[0]), 2)

                if prediction_probability >= POSTURE_ERROR_THRESHOLD:
                    posture = predicted_class
                cv2.rectangle(image, (0, 0), (500, 40), (245, 117, 16), -1)

                cv2.putText(image, "RIGHT", (15, 12), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(image, str(right_arm_analysis.counter) if right_arm_analysis.is_visible else "UNK",
                            (10, 30),
                            cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255), 2, cv2.LINE_AA)

                cv2.putText(image, "LEFT", (95, 12), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(image, str(left_arm_analysis.counter) if left_arm_analysis.is_visible else "UNK", (100, 30),
                            cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255), 2, cv2.LINE_AA)

                cv2.putText(image, "R_PC", (165, 12), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(image, str(right_arm_analysis.detected_errors["PEAK_CONTRACTION"]), (160, 30),
                            cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255), 2, cv2.LINE_AA)
                cv2.putText(image, "R_LUA", (225, 12), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(image, str(right_arm_analysis.detected_errors["LOOSE_UPPER_ARM"]), (220, 30),
                            cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255), 2, cv2.LINE_AA)

                cv2.putText(image, "L_PC", (300, 12), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(image, str(left_arm_analysis.detected_errors["PEAK_CONTRACTION"]), (295, 30),
                            cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255), 2, cv2.LINE_AA)
                cv2.putText(image, "L_LUA", (380, 12), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(image, str(left_arm_analysis.detected_errors["LOOSE_UPPER_ARM"]), (375, 30),
                            cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255), 2, cv2.LINE_AA)

                cv2.putText(image, "LB", (460, 12), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(image, str("C" if posture == 0 else "L") + f" ,{predicted_class}, {prediction_probability}",
                            (440, 30), cv2.FONT_HERSHEY_COMPLEX, 0.3, (255, 255, 255), 1, cv2.LINE_AA)

                if left_arm_analysis.is_visible:
                    cv2.putText(image, str(left_bicep_curl_angle),
                                tuple(np.multiply(left_arm_analysis.elbow, video_dimensions).astype(int)),
                                cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)
                    cv2.putText(image, str(left_ground_upper_arm_angle),
                                tuple(np.multiply(left_arm_analysis.shoulder, video_dimensions).astype(int)),
                                cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)

                if right_arm_analysis.is_visible:
                    cv2.putText(image, str(right_bicep_curl_angle),
                                tuple(np.multiply(right_arm_analysis.elbow, video_dimensions).astype(int)),
                                cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 0), 1, cv2.LINE_AA)
                    cv2.putText(image, str(right_ground_upper_arm_angle),
                                tuple(np.multiply(right_arm_analysis.shoulder, video_dimensions).astype(int)),
                                cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 0), 1, cv2.LINE_AA)

            except Exception as e:
                print(f"Error: {e}")

            # cv2.imshow("CV2", image)
            photo = ImageTk.PhotoImage(image=Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB)))
            canvas.create_image(0, 0, image=photo, anchor=tk.NW)
            canvas.photo = photo
            canvas.update()

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    cap.release()
    cv2.destroyAllWindows()

    for i in range(1, 5):
        cv2.waitKey(1)


class handDetector:
    def __init__(self, mode=False, maxHands=1, modelComplexity=1, detectionCon=0.5, trackingCon=0.5):
        self.mode = mode
        self.maxHands = maxHands
        self.modelComplexity = modelComplexity
        self.detectionCon = detectionCon
        self.trackingCon = trackingCon

        self.mpHands = mp.solutions.hands
        self.hands = self.mpHands.Hands(self.mode, self.maxHands, self.modelComplexity, self.detectionCon,
                                        self.trackingCon)
        self.mpDraw = mp.solutions.drawing_utils

    def findHands(self, img, draw=True):
        imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        self.results = self.hands.process(imgRGB)

        if self.results.multi_hand_landmarks:
            for handLms in self.results.multi_hand_landmarks:

                if draw:
                    self.mpDraw.draw_landmarks(img, handLms, self.mpHands.HAND_CONNECTIONS)

        return img

    def findPosition(self, img, handNo=0, draw=True):

        lmList = []

        if self.results.multi_hand_landmarks:
            myHand = self.results.multi_hand_landmarks[handNo]

            for id, lm in enumerate(myHand.landmark):
                h, w, c = img.shape
                cx, cy = int(lm.x * w), int(lm.y * h)

                lmList.append([id, cx, cy])

                if draw:
                    cv2.circle(img, (cx, cy), 15, (255, 0, 255), cv2.FILLED)

        return lmList


def countFingers(image, hand_landmarks, handNo=0):
    # global text_to_display
    global start_or_not
    start_or_not = False

    if hand_landmarks:
        landmarks = hand_landmarks[handNo].landmark
        fingers = []
        for lm_index in tipIds:
            finger_tip_y = landmarks[lm_index].y
            finger_bottom_y = landmarks[lm_index - 2].y

            if lm_index != 4:
                if finger_tip_y < finger_bottom_y:
                    fingers.append(1)
                    print("FINGER with id ", lm_index, " is Open")

                if finger_tip_y > finger_bottom_y:
                    fingers.append(0)
                    print("FINGER with id ", lm_index, " is Closed")

        totalFingers = fingers.count(1)

        text = f"Fingers: {totalFingers}"
        text_for_start = 'Start monitoring'
        text_for_stop = 'Stop monitoring'
        finger_first = 'finger 1'
        finger_second = 'finger 2'
        finger_third = 'finger 3'

        text_color = (0, 255, 0)

        if totalFingers == 0:
            start_or_not = True
        else:
            start_or_not = False

        if start_or_not:
            if totalFingers == 0:
                text_to_display = text_for_start
            elif totalFingers == 1:
                text_to_display = finger_first
            elif totalFingers == 2:
                text_to_display = finger_second
            elif totalFingers == 3:
                text_to_display = finger_third
            elif totalFingers == 4:
                text_to_display = text_for_stop
            else:
                text_to_display = text

            text_width, _ = cv2.getTextSize(text_to_display, cv2.FONT_HERSHEY_SIMPLEX, 1, 2)[0]
            text_x = (image.shape[1] - text_width) // 2
            cv2.putText(image, text_to_display, (text_x, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, text_color, 2)

        return totalFingers


def show_camera_feed(window, cap):
    root.title("GYM AI")
    label.pack_forget()
    ok_button.pack_forget()
    canvas = tk.Canvas(window, width=640, height=480)
    canvas.pack()
    detector = handDetector()
    while True:
        success, img = cap.read()
        img = detector.findHands(img)

        image = cv2.flip(img, 1)
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        results = hands.process(image_rgb)
        hand_landmarks = results.multi_hand_landmarks
        print(hand_landmarks)
        count = countFingers(img, hand_landmarks)
        if count == 1:
            track_biceps(canvas, cap)
        elif count == 2:
            track_sitUps(canvas, cap)
        elif count == 3:
            track_planks(canvas, cap)
        else:
            pass

        photo = ImageTk.PhotoImage(image=Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB)))
        canvas.create_image(0, 0, image=photo, anchor=tk.NW)
        canvas.photo = photo
        window.update()


def main(cap):
    global root, label, ok_button
    root = tk.Tk()
    root.title("GYM AI")
    root.geometry("640x480")
    instructions_text = ("Welcome to the GYM AI! \nInstructions:\n\n"
                         " 1. Make a fist to start Monitoring\n"
                         " 2. Show ✋ to stop Monitoring\n"
                         " 3. Show one finger ☝ for biceps exercise\n"
                         " 4. Show two fingers ✌ for sit-ups exercise\n"
                         " 5. Show three fingers for plank exercise")
    label = tk.Label(root, text=instructions_text)
    label.pack()
    ok_button = tk.Button(root, text="OK", command=lambda: show_camera_feed(root, cap))
    ok_button.pack()
    root.mainloop()


if __name__ == '__main__':
    main(cv2.VideoCapture(0))

